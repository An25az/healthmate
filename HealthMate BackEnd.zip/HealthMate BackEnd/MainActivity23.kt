package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity23 : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    // UI elements
    private lateinit var nameTextView: TextView
    private lateinit var heightTextView: TextView
    private lateinit var weightTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var bmiTextView: TextView
    private lateinit var caloriesBurnedTextView: TextView
    private lateinit var sleepTextView: TextView
    private lateinit var heartRateTextView: TextView
    private lateinit var editButton: ImageView // ImageView for edit button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main23)

        // Initialize Firebase Auth and Database
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Link UI elements to their views
        nameTextView = findViewById(R.id.profilenametextView)
        heightTextView = findViewById(R.id.heightnumbertextView)
        weightTextView = findViewById(R.id.weightnumbertextView)
        ageTextView = findViewById(R.id.agenumbertextView)
        bmiTextView = findViewById(R.id.bmiValueTextView)
        caloriesBurnedTextView = findViewById(R.id.caloriesBurnedValueTextView)
        sleepTextView = findViewById(R.id.sleepValueTextView)
        heartRateTextView = findViewById(R.id.heartRateValueTextView)
        editButton = findViewById(R.id.editButton) // Link the edit button ImageView

        // Fetch user data from Firebase
        fetchUserData()

        // Set an onClickListener for the edit button to navigate to MainActivity27
        editButton.setOnClickListener {
            val intent = Intent(this, MainActivity27::class.java)
            startActivity(intent)
        }
    }

    private fun fetchUserData() {
        val currentUser = auth.currentUser

        if (currentUser != null) {
            val userId = currentUser.uid
            val userProfileRef = database.child("UserProfiles").child(userId)

            userProfileRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Extract user data from Firebase snapshot
                        val name = snapshot.child("name").getValue(String::class.java) ?: "N/A"
                        val height = snapshot.child("height").getValue(String::class.java) ?: "N/A"
                        val weight = snapshot.child("weight").getValue(String::class.java) ?: "N/A"
                        val age = snapshot.child("age").getValue(String::class.java) ?: "N/A"
                        val bmi = snapshot.child("bmi").getValue(String::class.java) ?: "N/A"
                        val caloriesBurned = snapshot.child("caloriesBurned").getValue(String::class.java) ?: "N/A"
                        val sleepTime = snapshot.child("sleepTime").getValue(String::class.java) ?: "N/A"
                        val heartRate = snapshot.child("heartRate").getValue(String::class.java) ?: "N/A"

                        // Update the UI with the fetched data
                        nameTextView.text = name
                        heightTextView.text = "$height cm"
                        weightTextView.text = "$weight kg"
                        ageTextView.text = "$age Y"
                        bmiTextView.text = bmi
                        caloriesBurnedTextView.text = "$caloriesBurned kcal"
                        sleepTextView.text = "$sleepTime H"
                        heartRateTextView.text = "$heartRate bpm"
                    } else {
                        Toast.makeText(this@MainActivity23, "User data not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@MainActivity23, "Failed to load data", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "No logged-in user", Toast.LENGTH_SHORT).show()
        }
    }
}
