package com.alikhan.healthmate

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity26 : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private val CAMERA_REQUEST_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main26)

        // Initialize Firebase Auth and Database
        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().reference

        // Open camera on activity creation
        openCamera()
    }

    private fun openCamera() {
        // Create an intent to open the camera
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) != null) {
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
        } else {
            Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            saveImageLocally(imageBitmap)
        }
    }

    private fun saveImageLocally(imageBitmap: Bitmap) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid

            // Create a timestamp for the image file name
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val imageFileName = "IMG_$timestamp.jpg"

            // Save the image to internal storage (app's private storage)
            val imageFile = File(filesDir, imageFileName)
            try {
                val fileOutputStream = FileOutputStream(imageFile)
                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream)
                fileOutputStream.flush()
                fileOutputStream.close()

                // Save the path (URI) to Firebase Realtime Database
                saveImagePathToDatabase(userId, imageFile.absolutePath)

            } catch (e: IOException) {
                Log.e("ImageSave", "Error saving image", e)
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "No logged-in user", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveImagePathToDatabase(userId: String, imagePath: String) {
        val userRef = databaseReference.child("OCR Images").child(userId)
        val imageData = hashMapOf("imagePath" to imagePath)

        userRef.push().setValue(imageData)
            .addOnSuccessListener {
                Log.d("Firebase", "Image path saved to database")
                Toast.makeText(this, "Image path saved successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Log.e("Firebase", "Failed to save image path", it)
                Toast.makeText(this, "Failed to save image path", Toast.LENGTH_SHORT).show()
            }
    }
}
