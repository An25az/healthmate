package com.alikhan.healthmate

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity27 : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main27)

        // Initialize Firebase Auth and Database
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference.child("UserProfiles")

        // Find views by ID
        val nameEditText: EditText = findViewById(R.id.editName)
        val heightEditText: EditText = findViewById(R.id.editHeight)
        val weightEditText: EditText = findViewById(R.id.editWeight)
        val ageEditText: EditText = findViewById(R.id.editAge)
        val bmiEditText: EditText = findViewById(R.id.editBmi)
        val heartRateEditText: EditText = findViewById(R.id.editHeartRate)
        val caloriesBurnedEditText: EditText = findViewById(R.id.editCaloriesBurned)
        val sleepTimeEditText: EditText = findViewById(R.id.editSleepTime)
        val saveButton: Button = findViewById(R.id.saveButton)

        // Set click listener for save button
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val height = heightEditText.text.toString().trim()
            val weight = weightEditText.text.toString().trim()
            val age = ageEditText.text.toString().trim()
            val bmi = bmiEditText.text.toString().trim()
            val heartRate = heartRateEditText.text.toString().trim()
            val caloriesBurned = caloriesBurnedEditText.text.toString().trim()
            val sleepTime = sleepTimeEditText.text.toString().trim()

            // Validate input
            if (name.isEmpty() || height.isEmpty() || weight.isEmpty() || age.isEmpty() ||
                bmi.isEmpty() || heartRate.isEmpty() || caloriesBurned.isEmpty() || sleepTime.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Save data to Firebase
                saveUserProfile(name, height, weight, age, bmi, heartRate, caloriesBurned, sleepTime)
            }
        }
    }

    // Function to save the user profile in Firebase
    private fun saveUserProfile(name: String, height: String, weight: String, age: String,
                                bmi: String, heartRate: String, caloriesBurned: String, sleepTime: String) {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            val userProfile = UserProfile(name, height, weight, age, bmi, heartRate, caloriesBurned, sleepTime)

            // Save data under the 'UserProfiles' node with the user's UID as the key
            database.child(userId).setValue(userProfile)
                .addOnSuccessListener {
                    Toast.makeText(this, "Details saved successfully", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to save details", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "No authenticated user found", Toast.LENGTH_SHORT).show()
        }
    }
}
