package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity9 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main9)

        // Find the button by its ID
        val next9Button = findViewById<Button>(R.id.next9Button)
        val confirm9Button = findViewById<Button>(R.id.confirm9Button)

        // Set an onClickListener to navigate to MainActivity10
        next9Button.setOnClickListener {
            // Create an intent to start MainActivity10
            val intent = Intent(this, MainActivity10::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity12
        confirm9Button.setOnClickListener {
            // Create an intent to start MainActivity12
            val intent = Intent(this, MainActivity12::class.java)
            startActivity(intent)
        }

    }
}
