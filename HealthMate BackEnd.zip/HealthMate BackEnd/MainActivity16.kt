package com.alikhan.healthmate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity16 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main16)

        val backarrow = findViewById<ImageView>(R.id.backarrow)

        // Set an onClickListener to navigate to MainActivity14
        backarrow.setOnClickListener {
            // Create an intent to start MainActivity14
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }
    }
}