package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity11 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main11)

        val confirm11Button = findViewById<Button>(R.id.confirm11Button)

        // Set an onClickListener to navigate to MainActivity12
        confirm11Button.setOnClickListener {
            // Create an intent to start MainActivity12
            val intent = Intent(this, MainActivity12::class.java)
            startActivity(intent)
        }

    }
}
