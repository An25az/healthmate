package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity3 : AppCompatActivity() {

    // Firebase Authentication instance
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Find views by ID
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val firstNameEditText = findViewById<EditText>(R.id.firstnameEditText)
        val lastNameEditText = findViewById<EditText>(R.id.lastnameEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val loginText = findViewById<TextView>(R.id.loginText)

        // Handle register button click
        registerButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val firstName = firstNameEditText.text.toString().trim()
            val lastName = lastNameEditText.text.toString().trim()

            // Validate input fields
            if (email.isNotEmpty() && password.isNotEmpty() && firstName.isNotEmpty() && lastName.isNotEmpty()) {
                // Register user with Firebase Auth
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            // Get the unique user ID (UID) from Firebase Auth
                            val userId = auth.currentUser?.uid ?: ""

                            // Create user object
                            val user = User(userId, firstName, lastName, email)

                            // Save user data to Firebase Realtime Database
                            val database = FirebaseDatabase.getInstance().getReference("Users")
                            database.child(userId).setValue(user)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show()
                                    // Navigate to the next activity
                                    startActivity(Intent(this, MainActivity4::class.java))
                                    finish() // Close the current activity
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "Failed to store user data.", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle login text click
        loginText.setOnClickListener {
            startActivity(Intent(this, MainActivity2::class.java))
        }
    }

    // Define a User data class
    data class User(val id: String, val firstName: String, val lastName: String, val email: String)
}
