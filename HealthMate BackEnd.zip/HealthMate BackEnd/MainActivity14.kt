package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity14 : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var bmiTextView: TextView
    private lateinit var heartRateTextView: TextView
    private lateinit var nameTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main14)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Initialize views
        bmiTextView = findViewById(R.id.bmiTextView)
        heartRateTextView = findViewById(R.id.heartratetextview)
        nameTextView = findViewById(R.id.nametextView)
        val trackyouractivityButton = findViewById<Button>(R.id.trackyouractivityButton)
        val notificationlogo = findViewById<ImageView>(R.id.notificationlogo)
        val seedetailstextview = findViewById<TextView>(R.id.seedetailstextview)
        val profilelogo = findViewById<ImageView>(R.id.profilelogo)
        val homelogo = findViewById<ImageView>(R.id.homelogo)
        val activitylogo = findViewById<ImageView>(R.id.activitylogo)
        val cameralogo = findViewById<ImageView>(R.id.cameralogo)
        val todaytargetimage = findViewById<ImageView>(R.id.todaytargetimage)

        // Fetch data from Firebase
        fetchNameFromFirebase()
        fetchBMIFromFirebase()
        fetchHeartRateFromFirebase()

        // OnClick listeners for navigation
        trackyouractivityButton.setOnClickListener {
            val intent = Intent(this, MainActivity17::class.java)
            startActivity(intent)
        }

        notificationlogo.setOnClickListener {
            val intent = Intent(this, MainActivity16::class.java)
            startActivity(intent)
        }

        seedetailstextview.setOnClickListener {
            val intent = Intent(this, MainActivity15::class.java)
            startActivity(intent)
        }

        profilelogo.setOnClickListener {
            val intent = Intent(this, MainActivity23::class.java)
            startActivity(intent)
        }

        homelogo.setOnClickListener {
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }

        activitylogo.setOnClickListener {
            val intent = Intent(this, MainActivity17::class.java)
            startActivity(intent)
        }

        cameralogo.setOnClickListener {
            val intent = Intent(this, MainActivity26::class.java)
            startActivity(intent)
        }

        todaytargetimage.setOnClickListener {
            val intent = Intent(this, MainActivity29::class.java)
            startActivity(intent)
        }
    }

    // Function to fetch the name from Firebase
    private fun fetchNameFromFirebase() {
        val userId = auth.currentUser?.uid

        if (userId != null) {
            val nameReference = database.child("UserProfiles").child(userId).child("name")

            nameReference.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val name = snapshot.getValue(String::class.java)
                    if (name != null) {
                        nameTextView.text = name
                    } else {
                        nameTextView.text = "Name not available"
                    }
                } else {
                    nameTextView.text = "Name not found"
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to fetch Name", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to fetch BMI from Firebase and display it
    private fun fetchBMIFromFirebase() {
        val userId = auth.currentUser?.uid

        if (userId != null) {
            val bmiReference = database.child("UserProfiles").child(userId).child("bmi")

            bmiReference.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val bmi = snapshot.getValue(String::class.java)
                    if (bmi != null) {
                        bmiTextView.text = bmi
                    } else {
                        bmiTextView.text = "BMI not available"
                    }
                } else {
                    bmiTextView.text = "BMI not found"
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to fetch BMI", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to fetch Heart Rate from Firebase and display it
    private fun fetchHeartRateFromFirebase() {
        val userId = auth.currentUser?.uid

        if (userId != null) {
            val heartRateReference = database.child("UserProfiles").child(userId).child("heartRate")

            heartRateReference.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val heartRate = snapshot.getValue(String::class.java)?.toInt()
                    if (heartRate != null) {
                        // Update the heart rate text
                        heartRateTextView.text = "$heartRate bpm"
                    } else {
                        heartRateTextView.text = "Heart Rate not available"
                    }
                } else {
                    heartRateTextView.text = "Heart Rate not found"
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to fetch Heart Rate", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}
