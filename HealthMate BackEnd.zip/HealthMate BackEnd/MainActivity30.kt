package com.alikhan.healthmate

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity30 : AppCompatActivity() {

    private lateinit var latestActivityEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main30)

        // Initialize Firebase components
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        // Initialize UI elements
        latestActivityEditText = findViewById(R.id.latestActivityEditText)
        saveButton = findViewById(R.id.saveButton)

        // Set onClickListener for save button
        saveButton.setOnClickListener {
            saveLatestActivity()
        }
    }

    private fun saveLatestActivity() {
        // Get the latest activity entered by the user
        val latestActivity = latestActivityEditText.text.toString()

        if (latestActivity.isNotEmpty()) {
            val userId = auth.currentUser?.uid
            if (userId != null) {
                // Reference to "Latest Activities" in Firebase
                val latestActivitiesRef = database.getReference("Latest Activities").child(userId)

                // Get the number of existing activities for the user to create a new activity name
                latestActivitiesRef.get().addOnSuccessListener { snapshot ->
                    val activityCount = snapshot.childrenCount.toInt()
                    val activityName = "Latest Activity ${activityCount + 1}"

                    // Store the new activity under the generated name
                    latestActivitiesRef.child(activityName).setValue(latestActivity)
                        .addOnSuccessListener {
                            // Success message
                            Toast.makeText(this, "Activity saved successfully!", Toast.LENGTH_SHORT).show()
                            // Clear the input field
                            latestActivityEditText.text.clear()
                        }
                        .addOnFailureListener {
                            // Error message
                            Toast.makeText(this, "Failed to save activity. Please try again.", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        } else {
            // Validation for empty activity input
            Toast.makeText(this, "Please enter an activity.", Toast.LENGTH_SHORT).show()
        }
    }
}
