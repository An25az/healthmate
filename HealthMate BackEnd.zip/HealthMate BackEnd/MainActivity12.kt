package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class MainActivity12 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main12)

        // Find the button by its ID
        val goToHomeButton: Button = findViewById(R.id.gotohomeButton)

        // Set an OnClickListener on the button
        goToHomeButton.setOnClickListener {
            // Create an Intent to start MainActivity14
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }
    }
}
