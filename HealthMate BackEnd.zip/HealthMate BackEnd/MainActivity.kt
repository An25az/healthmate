package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the button by its ID
        val getStartedButton = findViewById<Button>(R.id.getStartedButton)

        // Set an onClickListener to navigate to MainActivity2
        getStartedButton.setOnClickListener {
            // Create an intent to start MainActivity2
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }
    }
}
