package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity29 : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private lateinit var waterIntakeTextView: TextView
    private lateinit var calorieIntakeTextView: TextView
    private lateinit var footStepsTextView: TextView
    private lateinit var workoutTimeTextView: TextView
    private lateinit var sleepTimeTextView: TextView
    private lateinit var totalMealsTextView: TextView

    private lateinit var backArrow: ImageView
    private lateinit var todayTargetImage1: ImageView
    private lateinit var todayTargetImage2: ImageView
    private lateinit var todayTargetImage3: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main29)

        // Initialize Firebase components
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("UserTargets")

        // Initialize UI elements
        waterIntakeTextView = findViewById(R.id.waterIntakeTextView)
        calorieIntakeTextView = findViewById(R.id.calorieIntakeTextView)
        footStepsTextView = findViewById(R.id.footStepsTextView)
        workoutTimeTextView = findViewById(R.id.workoutTimeTextView)
        sleepTimeTextView = findViewById(R.id.sleepTimeTextView)
        totalMealsTextView = findViewById(R.id.totalMealsTextView)
        backArrow = findViewById(R.id.backarrow)
        todayTargetImage1 = findViewById(R.id.todaytargetimage1)
        todayTargetImage2 = findViewById(R.id.todaytargetimage2)
        todayTargetImage3 = findViewById(R.id.todaytargetimage3)

        // Set up back arrow action (if needed)
        backArrow.setOnClickListener {
            onBackPressed() // Navigates back when clicked
        }

        // Fetch and display target data from Firebase
        fetchTargetData()

        // Set onClickListeners for the target images
        todayTargetImage1.setOnClickListener {
            navigateToMainActivity28()
        }

        todayTargetImage2.setOnClickListener {
            navigateToMainActivity28()
        }

        todayTargetImage3.setOnClickListener {
            navigateToMainActivity28()
        }
    }

    private fun fetchTargetData() {
        val userId = auth.currentUser?.uid

        if (userId == null) {
            Toast.makeText(this, "User not authenticated!", Toast.LENGTH_SHORT).show()
            return
        }

        // Reference to the specific user target data in Firebase
        database.child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Check if data exists for this user
                if (snapshot.exists()) {
                    // Get the TargetData from the snapshot
                    val targetData = snapshot.getValue(TargetData::class.java)

                    // Check if targetData is null or not
                    if (targetData != null) {
                        // Update the UI with the fetched data
                        waterIntakeTextView.text = "${targetData.waterIntake} ml"
                        calorieIntakeTextView.text = "${targetData.calorieIntake} kcal"
                        footStepsTextView.text = "${targetData.footSteps} steps"
                        workoutTimeTextView.text = "${targetData.workoutTime} mins"
                        sleepTimeTextView.text = "${targetData.sleepTime} hours"
                        totalMealsTextView.text = "${targetData.totalMeals} meals"
                    } else {
                        // Handle the case where the data is not found
                        Toast.makeText(this@MainActivity29, "No data found for the user.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    // Handle the case where there is no data
                    Toast.makeText(this@MainActivity29, "No data found for the user.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle database read error
                Toast.makeText(this@MainActivity29, "Failed to fetch data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Navigate to MainActivity28
    private fun navigateToMainActivity28() {
        val intent = Intent(this, MainActivity28::class.java)
        startActivity(intent)
    }
}
