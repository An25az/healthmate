package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.content.Intent

class MainActivity8 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main8)

        // Find the ImageView by its ID
        val skip1image = findViewById<ImageView>(R.id.skip1image)

        // Set an onClickListener to navigate to MainActivity9
        skip1image.setOnClickListener {
            // Create an intent to start MainActivity9
            val intent = Intent(this, MainActivity9::class.java)
            startActivity(intent)
        }
    }
}