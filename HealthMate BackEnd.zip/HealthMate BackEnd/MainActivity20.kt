package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.alikhan.healthmate.MainActivity23

class MainActivity20 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main20)

        // Find the button by its ID
        val seeMoreBreakfastButton = findViewById<TextView>(R.id.seemorebreakfast)
        val seemorelunch = findViewById<TextView>(R.id.seemorelunch)
        val seemoredinner = findViewById<TextView>(R.id.seemoredinner)
        val profilelogo = findViewById<ImageView>(R.id.profilelogo)
        val homelogo = findViewById<ImageView>(R.id.homelogo)
        val activitylogo = findViewById<ImageView>(R.id.activitylogo)
        val cameralogo = findViewById<ImageView>(R.id.cameralogo)
        val backarrow = findViewById<ImageView>(R.id.backarrow)


        // Set an onClickListener to navigate to MainActivity18
        seeMoreBreakfastButton.setOnClickListener {
            val intent = Intent(this, MainActivity18::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity24
        seemorelunch.setOnClickListener {
            val intent = Intent(this, MainActivity24::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity25
        seemoredinner.setOnClickListener {
            val intent = Intent(this, MainActivity25::class.java)
            startActivity(intent)
        }


        // Set an onClickListener to navigate to MainActivity23
        profilelogo.setOnClickListener {
            // Create an intent to start MainActivity23
            val intent = Intent(this, MainActivity23::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity14
        homelogo.setOnClickListener {
            // Create an intent to start MainActivity14
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity17
        activitylogo.setOnClickListener {
            // Create an intent to start MainActivity17
            val intent = Intent(this, MainActivity17::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity26
        cameralogo.setOnClickListener {
            // Create an intent to start MainActivity26
            val intent = Intent(this, MainActivity26::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity17
        backarrow.setOnClickListener {
            // Create an intent to start MainActivity17
            val intent = Intent(this, MainActivity17::class.java)
            startActivity(intent)
        }

    }
}
