package com.alikhan.healthmate

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity28 : AppCompatActivity() {

    private lateinit var waterIntakeEditText: EditText
    private lateinit var calorieIntakeEditText: EditText
    private lateinit var footStepsEditText: EditText
    private lateinit var workoutTimeEditText: EditText
    private lateinit var sleepTimeEditText: EditText
    private lateinit var totalMealsEditText: EditText  // New EditText
    private lateinit var setTargetButton: Button

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main28)

        // Initialize Firebase components
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("UserTargets")

        // Initialize UI elements
        waterIntakeEditText = findViewById(R.id.waterIntakeEditText)
        calorieIntakeEditText = findViewById(R.id.calorieIntakeEditText)
        footStepsEditText = findViewById(R.id.footStepsEditText)
        workoutTimeEditText = findViewById(R.id.workoutTimeEditText)
        sleepTimeEditText = findViewById(R.id.sleepTimeEditText)
        totalMealsEditText = findViewById(R.id.totalMealsEditText)  // Initialize totalMealsEditText
        setTargetButton = findViewById(R.id.setTargetButton)

        // Set click listener for the button
        setTargetButton.setOnClickListener {
            saveTargetData()
        }
    }

    private fun saveTargetData() {
        val userId = auth.currentUser?.uid

        if (userId == null) {
            Toast.makeText(this, "User not authenticated!", Toast.LENGTH_SHORT).show()
            return
        }

        // Retrieve data from input fields
        val waterIntake = waterIntakeEditText.text.toString().trim()
        val calorieIntake = calorieIntakeEditText.text.toString().trim()
        val footSteps = footStepsEditText.text.toString().trim()
        val workoutTime = workoutTimeEditText.text.toString().trim()
        val sleepTime = sleepTimeEditText.text.toString().trim()
        val totalMeals = totalMealsEditText.text.toString().trim()  // Get the totalMeals value

        // Validate inputs
        if (waterIntake.isEmpty() || calorieIntake.isEmpty() || footSteps.isEmpty() || workoutTime.isEmpty() || sleepTime.isEmpty() || totalMeals.isEmpty()) {
            Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show()
            return
        }

        // Create a data object
        val targetData = TargetData(
            waterIntake = waterIntake.toInt(),
            calorieIntake = calorieIntake.toInt(),
            footSteps = footSteps.toInt(),
            workoutTime = workoutTime.toInt(),
            sleepTime = sleepTime.toInt(),
            totalMeals = totalMeals.toInt()
        )

        // Save the data to Firebase
        database.child(userId).setValue(targetData)
            .addOnSuccessListener {
                Toast.makeText(this, "Target set successfully!", Toast.LENGTH_SHORT).show()
                clearInputFields()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to set target: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun clearInputFields() {
        waterIntakeEditText.text.clear()
        calorieIntakeEditText.text.clear()
        footStepsEditText.text.clear()
        workoutTimeEditText.text.clear()
        sleepTimeEditText.text.clear()
        totalMealsEditText.text.clear()  // Clear the new field
    }
}
