package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity2 : AppCompatActivity() {

    // Declare FirebaseAuth instance
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Initialize FirebaseAuth
        auth = FirebaseAuth.getInstance()

        // Find views by their ID
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerText = findViewById<TextView>(R.id.registerText)
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)

        // Login button logic
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            // Check if fields are not empty
            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Firebase Authentication to login
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // Get the logged-in user's UID
                            val userId = auth.currentUser?.uid ?: ""

                            // Retrieve user data from Firebase Realtime Database
                            val database = FirebaseDatabase.getInstance().getReference("Users")
                            database.child(userId).get()
                                .addOnSuccessListener { snapshot ->
                                    if (snapshot.exists()) {
                                        // Assuming User class is defined in MainActivity3
                                        val firstName = snapshot.child("firstName").value.toString()
                                        val lastName = snapshot.child("lastName").value.toString()

                                        // Show a welcome message
                                        Toast.makeText(this, "Welcome back, $firstName $lastName!", Toast.LENGTH_SHORT).show()

                                        // Navigate to the next activity
                                        val intent = Intent(this, MainActivity14::class.java)
                                        startActivity(intent)
                                        finish() // Close the login activity
                                    } else {
                                        Toast.makeText(this, "User data not found in database.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "Failed to retrieve user data: ${it.message}", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            // Login failed, show a Toast message
                            Toast.makeText(this, "Login failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                // Show a message if fields are empty
                Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate to the registration screen
        registerText.setOnClickListener {
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)
        }
    }
}
