package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity10 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main10)

        // Find the button by its ID
        val next10Button = findViewById<Button>(R.id.next10Button)
        val confirm10Button = findViewById<Button>(R.id.confirm10Button)

        // Set an onClickListener to navigate to MainActivity10
        next10Button.setOnClickListener {
            // Create an intent to start MainActivity10
            val intent = Intent(this, MainActivity11::class.java)
            startActivity(intent)
        }

        // Set an onClickListener to navigate to MainActivity12
        confirm10Button.setOnClickListener {
            // Create an intent to start MainActivity12
            val intent = Intent(this, MainActivity12::class.java)
            startActivity(intent)
        }

    }
}
