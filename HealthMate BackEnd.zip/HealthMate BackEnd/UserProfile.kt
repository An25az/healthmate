package com.alikhan.healthmate

data class UserProfile(
    val name: String = "",
    val height: String = "",
    val weight: String = "",
    val age: String = "",
    val bmi: String = "",
    val heartRate: String = "",
    val caloriesBurned: String = "",
    val sleepTime: String = ""
)
