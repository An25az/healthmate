package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        // Find the button by its ID
        val nextButton = findViewById<Button>(R.id.nextButton)

        // Set an onClickListener to navigate to MainActivity5
        nextButton.setOnClickListener {
            // Create an intent to start MainActivity5
            val intent = Intent(this, MainActivity5::class.java)
            startActivity(intent)
        }
    }
}
