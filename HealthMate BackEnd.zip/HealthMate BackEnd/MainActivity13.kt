package com.alikhan.healthmate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity13 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main13)
    }
}