package com.alikhan.healthmate

data class TargetData(
    val waterIntake: Int = 0,
    val calorieIntake: Int = 0,
    val footSteps: Int = 0,
    val workoutTime: Int = 0,
    val sleepTime: Int = 0,
    val totalMeals: Int = 0
)
