package com.alikhan.healthmate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity17 : AppCompatActivity() {

    private lateinit var waterIntakeTextView: TextView
    private lateinit var footStepsTextView: TextView
    private lateinit var latestActivity1TextView: TextView
    private lateinit var latestActivity2TextView: TextView
    private lateinit var database: FirebaseDatabase
    private lateinit var userRef: DatabaseReference
    private lateinit var latestActivitiesRef: DatabaseReference
    private lateinit var currentUserId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main17)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance()

        // Get the current user ID from Firebase Authentication
        currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: "someUserId" // Ensure this is the logged-in user

        // Reference to the user's data in the database
        userRef = database.reference.child("Users").child(currentUserId)

        // Reference to the "Latest Activities" node
        latestActivitiesRef = database.reference.child("Latest Activities").child(currentUserId)

        // Initialize the TextViews
        waterIntakeTextView = findViewById(R.id.waterIntakeText)
        footStepsTextView = findViewById(R.id.footStepsText)
        latestActivity1TextView = findViewById(R.id.latestactivity1textView)
        latestActivity2TextView = findViewById(R.id.latestactivity2textView)

        // Find other views by their IDs
        val checkMealPlannerButton = findViewById<Button>(R.id.checkmealplannerButton)
        val checkMealScheduleButton = findViewById<Button>(R.id.checkmealscheduleButton)
        val checksleepscheduleButton = findViewById<Button>(R.id.checksleepscheduleButton)
        val profilelogo = findViewById<ImageView>(R.id.profilelogo)
        val homelogo = findViewById<ImageView>(R.id.homelogo)
        val activitylogo = findViewById<ImageView>(R.id.activitylogo)
        val cameralogo = findViewById<ImageView>(R.id.cameralogo)
        val backarrow = findViewById<ImageView>(R.id.backarrow)
        val todaytarget = findViewById<ImageView>(R.id.todaytargetimage)
        val buttonlatestactivity1 = findViewById<ImageView>(R.id.buttonlatestactivity1)
        val buttonlatestactivity2 = findViewById<ImageView>(R.id.buttonlatestactivity2)

        buttonlatestactivity1.setOnClickListener {
            val intent = Intent(this, MainActivity30::class.java)
            startActivity(intent)
        }

        buttonlatestactivity2.setOnClickListener {
            val intent = Intent(this, MainActivity30::class.java)
            startActivity(intent)
        }

        // Set onClickListeners for buttons and other images (same as before)
        checkMealPlannerButton.setOnClickListener {
            val intent = Intent(this, MainActivity19::class.java)
            startActivity(intent)
        }

        checkMealScheduleButton.setOnClickListener {
            val intent = Intent(this, MainActivity20::class.java)
            startActivity(intent)
        }

        checksleepscheduleButton.setOnClickListener {
            val intent = Intent(this, MainActivity21::class.java)
            startActivity(intent)
        }

        profilelogo.setOnClickListener {
            val intent = Intent(this, MainActivity23::class.java)
            startActivity(intent)
        }

        homelogo.setOnClickListener {
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }

        activitylogo.setOnClickListener {
            val intent = Intent(this, MainActivity17::class.java)
            startActivity(intent)
        }

        cameralogo.setOnClickListener {
            val intent = Intent(this, MainActivity26::class.java)
            startActivity(intent)
        }

        backarrow.setOnClickListener {
            val intent = Intent(this, MainActivity14::class.java)
            startActivity(intent)
        }

        todaytarget.setOnClickListener {
            val intent = Intent(this, MainActivity28::class.java)
            startActivity(intent)
        }

        // Fetch data from Firebase
        getUserDataFromFirebase()
        getLatestActivitiesFromFirebase()
    }

    private fun getUserDataFromFirebase() {
        // Reference to the waterIntake and footSteps nodes in the "UserTargets" node
        val waterIntakeReference = database.reference.child("UserTargets").child(currentUserId).child("waterIntake")
        val footStepsReference = database.reference.child("UserTargets").child(currentUserId).child("footSteps")

        // Continuously fetch the water intake value
        waterIntakeReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val waterIntake = snapshot.getValue(Int::class.java) ?: 0
                    // Update the UI with the fetched water intake data
                    waterIntakeTextView.text = "$waterIntake ml"
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error (optional)
            }
        })

        // Continuously fetch the foot steps value
        footStepsReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val footSteps = snapshot.getValue(Int::class.java) ?: 0
                    // Update the UI with the fetched foot steps data
                    footStepsTextView.text = "$footSteps steps"
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error (optional)
            }
        })
    }

    private fun getLatestActivitiesFromFirebase() {
        // Reference to the "Latest Activities" node for the current user
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val latestActivitiesRef = FirebaseDatabase.getInstance().getReference("Latest Activities").child(userId ?: return)

        latestActivitiesRef.orderByKey().limitToLast(2).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    // Create a list to store the latest activities in reverse order
                    val activities = mutableListOf<String>()

                    // Loop through the snapshot and add activities to the list
                    snapshot.children.forEach { activitySnapshot ->
                        val activityDescription = activitySnapshot.getValue(String::class.java) ?: "No activity recorded"
                        activities.add(activityDescription)
                    }

                    // Update the UI with the latest activities, replace the older ones if there are more than 2
                    if (activities.size == 1) {
                        latestActivity1TextView.text = "${activities[0]}"
                        latestActivity2TextView.text = "No activity recorded"
                    } else if (activities.size == 2) {
                        latestActivity1TextView.text = "${activities[1]}"
                        latestActivity2TextView.text = "${activities[0]}"
                    }

                    // If no activities are recorded, update the TextViews accordingly
                    if (activities.isEmpty()) {
                        latestActivity1TextView.text = "No activity recorded"
                        latestActivity2TextView.text = "No activity recorded"
                    }
                } else {
                    // Handle the case where no data is found
                    latestActivity1TextView.text = "No activity recorded"
                    latestActivity2TextView.text = "No activity recorded"
                    Log.d("Firebase", "No data found for this user")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle any errors during data fetch
                Log.e("Firebase", "Error fetching data: ${error.message}")
            }
        })
    }
}
